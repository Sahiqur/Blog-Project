
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path("add_author/",views.add_author,name="add_author"),
    path("show_author/",views.show_author_data, name="show_author"),
    
]
