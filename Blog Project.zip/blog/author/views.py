from django.shortcuts import render,redirect
from django.http import HttpResponse
from . import forms
from .models import Author
# Create your views here.


def add_author(request):
    if request.method == 'POST':
        author_form = forms.AuthorForm(request.POST)
        if author_form.is_valid():
            author_form.save()
            return redirect("add_author")
    else:
        author_form = forms.AuthorForm()    
    return render(request,"add_author.html",{"author_form":author_form})

def show_author_data(request):
    authors_data = Author.objects.all()
    return render(request, "show_author_data.html",{"authors_data":authors_data})
