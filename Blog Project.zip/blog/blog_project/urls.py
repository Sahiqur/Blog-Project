
from django.contrib import admin
from django.urls import path,include
from .import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("",views.home, name="home"),
    path("delete/<int:id>",views.delete_data, name="delete_data"),
    path("update_data/<int:pk>",views.update_data, name="update_data"),
    path("author/",include("author.urls")),
    path("categories/",include("categories.urls")),
    path("post/",include("post.urls")),
    path("profiles/",include("profiles.urls")),
]
