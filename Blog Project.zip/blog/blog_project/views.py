from django.shortcuts import render,redirect
from django.http import HttpResponse
from post.forms import PostForm
from post.models import Post

def home(request):
    posts = Post.objects.all()
    return render(request,"home.html",{"posts":posts})



def delete_data(request,id):
    data = Post.objects.get(id=id)
    data.delete()
    return redirect("home")


def update_data(request,pk):
    data = Post.objects.get(pk=pk)
    if request.method == "POST":
        task_form = PostForm(request.POST, instance = data)
        if task_form.is_valid():
            task_form.save()
            return redirect("home")
    
    task_form=PostForm(instance = data)
    return render(request, "update.html", {"task_form":task_form})
        