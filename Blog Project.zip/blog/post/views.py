from django.shortcuts import render,redirect
from .import forms
from .models import Post
# Create your views here.

def add_post(request):
    if request.method == 'POST':
        data = forms.PostForm(request.POST)
        if data.is_valid():
            data.save()
            return redirect("add_post")
        
    else:
        data = forms.PostForm()
    return render(request,"add_post.html", {"data":data})



        
